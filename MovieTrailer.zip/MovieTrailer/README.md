# UdacityFullStackDeveloper
Student: McKinnely Bentley
Mentor:  Joel Colucci
Project: Udacity Movie Trailer
March :  21 March 2017

This project allows for one to brows an interactive web page (fresh_tomatoes.html).
The web page fresh_tomatoes.html allows for one to view movie trailers.
The name of all people involved are at the top of the media.py and entertainment_center.py files.
Assuming that one already has Python installed, one can just download the project run the entertainment_center.py file.
To grab the latest code associate with this project just go to  https://github.com/McKinnely/UdacityFullStackDeveloper and git it from my GitHub. 
To report a bug, just contact the email address at the link below.
My contact information is here: http://mbcodeguy.blogspot.com/p/about-me.html.
